package ml.mypals.litematicafastmove.mesh;

import ml.mypals.litematicafastmove.access.PlacementBlockAccessor;
import ml.mypals.litematicafastmove.config.FastMoveConfig;
import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.core.SectionPos;
import net.minecraft.gizmos.GizmoStyle;
import net.minecraft.gizmos.Gizmos;
import net.minecraft.world.phys.AABB;

import java.util.Collection;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 调试可视化：在独立网格正在处理的区段上画淡出的 Gizmo 框。
 * 琥珀色 = 提交局部重建，绿色 = 重建结果生效，灰色 = 前后都是空气而跳过，蓝色 = 整个投影完整重建
 */
public final class MeshDebugGizmos {
    private static final int QUEUED = 0xFFFFB000;
    private static final int APPLIED = 0xFF40FF80;
    private static final int SKIPPED = 0xFF808080;
    private static final int FULL = 0xFF40A0FF;
    private static final int MAX_PER_TICK = 512;

    private record Box(AABB aabb, int color) {}

    private static final Queue<Box> PENDING = new ConcurrentLinkedQueue<>();

    private MeshDebugGizmos() {}

    static boolean isEnabled() {
        return FastMoveConfig.DEBUG_GIZMOS.getBooleanValue();
    }

    // 完整重建：提交时蓝色，生效时绿色，只画整个投影的包围盒
    static void fullBuild(PlacementBlockAccessor accessor, BlockPos delta, boolean applied) {
        if (!isEnabled() || accessor == null) return;
        PENDING.add(new Box(new AABB(
                accessor.minPos.getX() + delta.getX(), accessor.minPos.getY() + delta.getY(), accessor.minPos.getZ() + delta.getZ(),
                accessor.maxPos.getX() + delta.getX() + 1, accessor.maxPos.getY() + delta.getY() + 1, accessor.maxPos.getZ() + delta.getZ() + 1),
                applied ? APPLIED : FULL));
    }

    static void sectionsQueued(PlacementBlockAccessor accessor, Collection<Long> keys, BlockPos delta) {
        addSections(accessor, keys, delta, QUEUED);
    }

    static void sectionsApplied(PlacementBlockAccessor accessor, Collection<Long> keys, BlockPos delta) {
        addSections(accessor, keys, delta, APPLIED);
    }

    static void sectionsSkipped(PlacementBlockAccessor accessor, Collection<Long> keys, BlockPos delta) {
        addSections(accessor, keys, delta, SKIPPED);
    }

    // 区段夹到投影包围盒，构建坐标 + delta = 世界坐标
    private static void addSections(PlacementBlockAccessor accessor, Collection<Long> keys, BlockPos delta, int color) {
        if (!isEnabled() || accessor == null || keys == null) return;

        BlockPos min = accessor.minPos;
        BlockPos max = accessor.maxPos;
        for (long key : keys) {
            int sx = SectionPos.x(key) << 4, sy = SectionPos.y(key) << 4, sz = SectionPos.z(key) << 4;
            int x0 = Math.max(sx, min.getX()), x1 = Math.min(sx + 15, max.getX());
            int y0 = Math.max(sy, min.getY()), y1 = Math.min(sy + 15, max.getY());
            int z0 = Math.max(sz, min.getZ()), z1 = Math.min(sz + 15, max.getZ());
            if (x0 > x1 || y0 > y1 || z0 > z1) continue;

            PENDING.add(new Box(new AABB(x0 + delta.getX(), y0 + delta.getY(), z0 + delta.getZ(),
                    x1 + delta.getX() + 1, y1 + delta.getY() + 1, z1 + delta.getZ() + 1), color));
        }
    }

    /**
     * 客户端 tick：把排队的框交给原版的 per-tick Gizmo 收集器，持续一段时间并淡出
     */
    public static void flush() {
        if (PENDING.isEmpty()) return;
        if (!isEnabled()) {
            PENDING.clear();
            return;
        }

        int millis = FastMoveConfig.DEBUG_GIZMO_MILLIS.getIntegerValue();
        try (var ignored = Minecraft.getInstance().collectPerTickGizmos()) {
            Box box;
            int count = 0;
            while (count++ < MAX_PER_TICK && (box = PENDING.poll()) != null) {
                int fill = (box.color() & 0x00FFFFFF) | 0x20000000;
                Gizmos.cuboid(box.aabb(), GizmoStyle.strokeAndFill(box.color(), 2.0f, fill))
                      .persistForMillis(millis)
                      .fadeOut();
            }
        }
    }
}
