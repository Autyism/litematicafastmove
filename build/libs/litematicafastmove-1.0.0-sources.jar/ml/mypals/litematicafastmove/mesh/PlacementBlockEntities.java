package ml.mypals.litematicafastmove.mesh;

import fi.dy.masa.litematica.render.IWorldSchematicRenderer;
import fi.dy.masa.litematica.render.LitematicaRenderer;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import ml.mypals.litematicafastmove.sync.PendingMoveTracker;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.function.LongConsumer;

/**
 * 被接管投影中需要显示的方块实体：位置由网格构建时统计，Litematica 区块重建时直接登记，
 * 不再逐格遍历投影
 */
public final class PlacementBlockEntities {
    private PlacementBlockEntities() {}

    /**
     * Litematica 重建区块 (cx, cz) 时调用：给出被接管投影在该区块内需要显示的方块实体 (世界坐标)
     */
    public static void forEachInChunk(int chunkX, int chunkZ, LongConsumer consumer) {
        for (Map.Entry<SchematicPlacement, PlacementMesh> entry : PlacementMeshManager.meshes().entrySet()) {
            SchematicPlacement placement = entry.getKey();
            PlacementMesh mesh = entry.getValue();
            BlockPos buildOrigin = mesh.blockEntityBuildOrigin;
            if (buildOrigin == null || mesh.blockEntities.isEmpty() || !placement.isRenderingEnabled()) continue;

            BlockPos offset = origin(placement).subtract(buildOrigin);
            for (long[] positions : mesh.blockEntities.values()) {
                for (long packed : positions) {
                    int x = BlockPos.getX(packed) + offset.getX();
                    int z = BlockPos.getZ(packed) + offset.getZ();
                    if ((x >> 4) == chunkX && (z >> 4) == chunkZ) {
                        consumer.accept(BlockPos.asLong(x, BlockPos.getY(packed) + offset.getY(), z));
                    }
                }
            }
        }
    }

    // 完整构建生效：整体替换，旧位置与新位置所在区块都需要 Litematica 重新登记
    static void replace(SchematicPlacement placement, PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer full, Set<Long> changedChunks) {
        BlockPos origin = origin(placement);
        BlockPos oldBuildOrigin = mesh.blockEntityBuildOrigin;
        if (oldBuildOrigin != null) {
            BlockPos oldOffset = origin.subtract(oldBuildOrigin);
            mesh.blockEntities.values().forEach(positions -> addChunksOf(positions, oldOffset, changedChunks));
        }

        mesh.blockEntities.clear();
        mesh.blockEntityBuildOrigin = full.buildOrigin;
        BlockPos offset = origin.subtract(full.buildOrigin);
        for (PlacementMesh.GpuSection section : full.uploaded) {
            if (section.blockEntities().length > 0) {
                mesh.blockEntities.put(section.key(), section.blockEntities());
                addChunksOf(section.blockEntities(), offset, changedChunks);
            }
        }
    }

    // 局部构建生效：只有列表真正变化的区段才需要重新登记
    static void update(SchematicPlacement placement, PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer partial, Set<Long> changedChunks) {
        BlockPos offset = origin(placement).subtract(partial.buildOrigin);
        Map<Long, long[]> updated = new HashMap<>();
        for (PlacementMesh.GpuSection section : partial.uploaded) {
            updated.put(section.key(), section.blockEntities());
        }

        for (long key : partial.keys) {
            long[] before = mesh.blockEntities.get(key);
            long[] after = updated.get(key);
            if (after != null && after.length == 0) after = null;
            if (Arrays.equals(before, after)) continue;

            addChunksOf(before, offset, changedChunks);
            addChunksOf(after, offset, changedChunks);
            if (after != null) {
                mesh.blockEntities.put(key, after);
            } else {
                mesh.blockEntities.remove(key);
            }
        }
    }

    // 交给 Litematica 重绘 (只剩登记方块实体，开销很小)，期间不触发独立网格自身的重建
    static void scheduleLitematicaChunks(Set<Long> chunks) {
        if (chunks.isEmpty()) return;

        PlacementMeshManager.pushDirtySuppression();
        try {
            IWorldSchematicRenderer renderer = LitematicaRenderer.getInstance().getWorldRenderer();
            for (long packed : chunks) {
                renderer.scheduleChunkRenders(ChunkPos.getX(packed), ChunkPos.getZ(packed), false);
            }
        } finally {
            PlacementMeshManager.popDirtySuppression();
        }
    }

    // 移动推迟提交期间，WorldSchematic 中的方块实体仍在 base 原点下
    private static BlockPos origin(SchematicPlacement placement) {
        PendingMoveTracker.MoveState pending = PendingMoveTracker.get(placement);
        return pending != null ? pending.baseOrigin : placement.getOrigin();
    }

    private static void addChunksOf(long[] positions, BlockPos offset, Set<Long> out) {
        if (positions == null) return;
        for (long packed : positions) {
            out.add(ChunkPos.pack((BlockPos.getX(packed) + offset.getX()) >> 4, (BlockPos.getZ(packed) + offset.getZ()) >> 4));
        }
    }
}
