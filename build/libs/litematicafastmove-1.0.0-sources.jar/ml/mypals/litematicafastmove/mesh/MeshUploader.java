package ml.mypals.litematicafastmove.mesh;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.renderpearl.api.buffers.GpuBuffer;
import com.mojang.renderpearl.api.device.GpuDevice;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import ml.mypals.litematicafastmove.LitematicaFastMove;
import ml.mypals.litematicafastmove.config.FastMoveConfig;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * 渲染线程：接收构建结果，按每帧预算上传 GPU buffer，上传完成后整体替换生效
 */
final class MeshUploader {
    private record Completed(PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer buffer) {}

    // 本帧剩余的上传预算 (字节数与截止时间)；每帧至少上传一个区段，保证进度
    private static final class Budget {
        long bytes = FastMoveConfig.UPLOAD_BYTES_PER_FRAME;
        final long deadline = System.nanoTime() + (long) (FastMoveConfig.UPLOAD_MILLIS_PER_FRAME * 1_000_000L);
        boolean usedAny;

        boolean hasRemaining() {
            return !this.usedAny || (this.bytes > 0 && System.nanoTime() < this.deadline);
        }
    }

    private static final Queue<Completed> COMPLETED = new ConcurrentLinkedQueue<>();
    private static final Queue<PlacementMesh> TO_CLOSE = new ConcurrentLinkedQueue<>();

    private MeshUploader() {}

    // 任意线程
    static void enqueueBuilt(PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer buffer) {
        COMPLETED.add(new Completed(mesh, buffer));
    }

    // 任意线程；GPU 资源在渲染线程释放
    static void enqueueClose(PlacementMesh mesh) {
        TO_CLOSE.add(mesh);
    }

    static void processQueues() {
        PlacementMesh closing;
        while ((closing = TO_CLOSE.poll()) != null) {
            closing.close();
        }

        Completed completed;
        while ((completed = COMPLETED.poll()) != null) {
            accept(completed.mesh(), completed.buffer());
        }

        Budget budget = new Budget();
        Set<Long> blockEntityChunks = new HashSet<>();

        for (Map.Entry<SchematicPlacement, PlacementMesh> entry : PlacementMeshManager.meshes().entrySet()) {
            if (!budget.hasRemaining()) break;
            SchematicPlacement placement = entry.getKey();
            PlacementMesh mesh = entry.getValue();

            PlacementMesh.BuiltPlacementBuffer full = mesh.uploadingFull;
            if (full != null) {
                upload(full, budget);
                if (!full.isFullyUploaded()) continue;
                activateFull(placement, mesh, full, blockEntityChunks);
            }

            // 局部结果按完成顺序上传，全部上传完才整体替换对应区段，期间继续绘制旧区段
            PlacementMesh.BuiltPlacementBuffer partial;
            while ((partial = mesh.uploadingPartials.peek()) != null && budget.hasRemaining()) {
                upload(partial, budget);
                if (!partial.isFullyUploaded()) break;
                mesh.uploadingPartials.poll();
                PlacementBlockEntities.update(placement, mesh, partial, blockEntityChunks);
                applyPartial(mesh, partial);
            }
        }

        PlacementBlockEntities.scheduleLitematicaChunks(blockEntityChunks);
        TranslucentSorter.applyResorted();
    }

    private static void accept(PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer buffer) {
        if (buffer.generation != mesh.requestedGeneration) {
            buffer.discard();
        } else if (buffer.isFull()) {
            if (mesh.uploadingFull != null) {
                mesh.uploadingFull.discard();
            }
            mesh.uploadingFull = buffer;
        } else if (mesh.uploadingFull == null && mesh.activeGeneration == buffer.generation) {
            mesh.uploadingPartials.add(buffer);
        } else {
            // 对应的完整构建还没上传完，等它生效后再排队
            mesh.deferredPartials.add(buffer);
        }
    }

    private static void activateFull(SchematicPlacement placement, PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer full,
                                     Set<Long> blockEntityChunks) {
        LitematicaFastMove.LOGGER.debug("Detached placement mesh ready: {} sections (generation {})",
                full.uploaded.size(), full.generation);
        mesh.active.values().forEach(PlacementMesh.GpuSection::close);
        mesh.active.clear();
        mesh.clipRebuildPending.clear();
        for (PlacementMesh.GpuSection section : full.uploaded) {
            mesh.active.put(section.key(), section);
        }
        mesh.activeGeneration = full.generation;
        mesh.activeBuildOrigin = full.buildOrigin;
        mesh.uploadingFull = null;
        PlacementBlockEntities.replace(placement, mesh, full, blockEntityChunks);

        // 旧网格的局部结果作废，新网格的局部结果接着排队上传
        mesh.uploadingPartials.forEach(PlacementMesh.BuiltPlacementBuffer::discard);
        mesh.uploadingPartials.clear();
        for (PlacementMesh.BuiltPlacementBuffer partial : mesh.deferredPartials) {
            if (partial.generation == mesh.activeGeneration) {
                mesh.uploadingPartials.add(partial);
            } else {
                partial.discard();
            }
        }
        mesh.deferredPartials.clear();
    }

    private static void applyPartial(PlacementMesh mesh, PlacementMesh.BuiltPlacementBuffer partial) {
        for (long key : partial.keys) {
            PlacementMesh.GpuSection old = mesh.active.remove(key);
            if (old != null) old.close();
            mesh.clipRebuildPending.remove(key);
        }
        for (PlacementMesh.GpuSection section : partial.uploaded) {
            if (section.hasBlocks() || !section.layers().isEmpty()) {
                mesh.active.put(section.key(), section);
            } else {
                section.close();
            }
        }
        partial.uploaded.clear();
    }

    private static void upload(PlacementMesh.BuiltPlacementBuffer buffer, Budget budget) {
        GpuDevice device = RenderSystem.getDevice();

        while (budget.hasRemaining() && !buffer.isFullyUploaded()) {
            budget.usedAny = true;
            PlacementMesh.CpuSection section = buffer.pending.get(buffer.nextToUpload++);
            List<PlacementMesh.GpuLayer> layers = new ArrayList<>(section.layers().size());
            for (PlacementMesh.CpuLayer layer : section.layers()) {
                budget.bytes -= layer.vertices().remaining();
                GpuBuffer vertexBuffer = device.createBuffer(() -> "litematicafastmove:placement_mesh",
                        GpuBuffer.USAGE_VERTEX | GpuBuffer.USAGE_COPY_DST, layer.vertices());
                GpuBuffer indexBuffer = null;
                PlacementMesh.SortInfo sort = null;
                if (layer.indices() != null) {
                    budget.bytes -= layer.indices().remaining();
                    indexBuffer = device.createBuffer(() -> "litematicafastmove:placement_mesh_indices",
                            GpuBuffer.USAGE_INDEX | GpuBuffer.USAGE_COPY_DST, layer.indices());
                    sort = new PlacementMesh.SortInfo(layer.sortState(), Double.NaN, Double.NaN, Double.NaN);
                }
                layer.free();
                layers.add(new PlacementMesh.GpuLayer(layer.layer(), layer.overlay(), vertexBuffer, layer.indexCount(),
                        indexBuffer, layer.indexType(), sort));
            }
            buffer.uploaded.add(new PlacementMesh.GpuSection(section.key(), section.origin(),
                    section.hasBlocks(), section.clientEmpty(), section.clip(), layers, section.blockEntities()));
        }
    }
}
