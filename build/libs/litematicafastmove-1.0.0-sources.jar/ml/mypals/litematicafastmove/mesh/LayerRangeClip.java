package ml.mypals.litematicafastmove.mesh;

import fi.dy.masa.litematica.data.DataManager;
import fi.dy.masa.malilib.util.LayerMode;
import fi.dy.masa.malilib.util.position.LayerRange;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/**
 * Litematica 渲染层范围在独立网格区段上的裁剪计算
 */
final class LayerRangeClip {
    // 层范围快照 (世界坐标)，null = 不限制
    record Range(Direction.Axis axis, int min, int max) {}

    private LayerRangeClip() {}

    static Range snapshot() {
        LayerRange range = DataManager.getRenderLayerRange();
        if (range == null || range.getLayerMode() == LayerMode.ALL) return null;
        return new Range(range.getAxis(), range.getMinLayerBoundary(), range.getMaxLayerBoundary());
    }

    /**
     * 区段 (构建坐标 sectionOrigin，世界坐标 = 构建坐标 + delta) 在层范围下需要的裁剪
     */
    static PlacementMesh.Clip compute(Range range, BlockPos min, BlockPos max, BlockPos sectionOrigin, BlockPos delta) {
        if (range == null) return null;

        Direction.Axis axis = range.axis();
        int origin = axis.choose(sectionOrigin.getX(), sectionOrigin.getY(), sectionOrigin.getZ());
        int d = axis.choose(delta.getX(), delta.getY(), delta.getZ());
        int secMin = Math.max(origin, axis.choose(min.getX(), min.getY(), min.getZ()));
        int secMax = Math.min(origin + 15, axis.choose(max.getX(), max.getY(), max.getZ()));
        int lo = Math.max(secMin + d, range.min());
        int hi = Math.min(secMax + d, range.max());

        if (lo <= secMin + d && hi >= secMax + d) return null;
        if (lo > hi) return new PlacementMesh.Clip(axis, 1, 0);
        return new PlacementMesh.Clip(axis, lo - d - origin, hi - d - origin);
    }
}
