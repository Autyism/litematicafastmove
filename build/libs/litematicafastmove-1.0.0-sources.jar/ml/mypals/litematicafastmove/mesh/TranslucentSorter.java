package ml.mypals.litematicafastmove.mesh;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.VertexSorting;
import ml.mypals.litematicafastmove.LitematicaFastMove;
import ml.mypals.litematicafastmove.config.FastMoveConfig;
import org.lwjgl.system.MemoryUtil;

import java.nio.ByteBuffer;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 半透明区段的重新排序：相机相对区段移动超过阈值后在后台重排索引，渲染线程回写索引缓冲
 */
final class TranslucentSorter {
    private record Resorted(PlacementMesh.GpuLayer layer, ByteBuffer indices, double x, double y, double z) {}

    private static final ExecutorService SORTER = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "LFMTranslucentSorter");
        t.setDaemon(true);
        return t;
    });
    private static final Queue<Resorted> RESORTED = new ConcurrentLinkedQueue<>();

    private int budget = FastMoveConfig.TRANSLUCENT_RESORTS_PER_FRAME;

    private TranslucentSorter() {}

    // 每帧新建一个，携带本帧的重新排序预算
    static TranslucentSorter forFrame() {
        return new TranslucentSorter();
    }

    /**
     * (rx, ry, rz)：相机相对区段原点的位置
     */
    void maybeResort(PlacementMesh.GpuLayer layer, double rx, double ry, double rz) {
        PlacementMesh.SortInfo sort = layer.sort();
        if (sort == null || sort.pending || this.budget <= 0) return;

        double dx = rx - sort.lastX, dy = ry - sort.lastY, dz = rz - sort.lastZ;
        double threshold = FastMoveConfig.TRANSLUCENT_RESORT_DISTANCE;
        if (!Double.isNaN(sort.lastX) && dx * dx + dy * dy + dz * dz <= threshold * threshold) return;

        this.budget--;
        sort.pending = true;
        int size = layer.indexCount() * layer.indexType().bytes;
        SORTER.submit(() -> {
            ByteBuffer indices = MemoryUtil.memAlloc(size);
            try {
                sort.state.writeSortedIndexBuffer(indices, VertexSorting.byDistance((float) rx, (float) ry, (float) rz));
                indices.position(0).limit(size);
                RESORTED.add(new Resorted(layer, indices, rx, ry, rz));
            } catch (Throwable e) {
                MemoryUtil.memFree(indices);
                LitematicaFastMove.LOGGER.debug("Failed to resort translucent section", e);
            }
        });
    }

    // 渲染线程：把排好序的索引写回 GPU
    static void applyResorted() {
        Resorted resorted;
        while ((resorted = RESORTED.poll()) != null) {
            PlacementMesh.GpuLayer layer = resorted.layer();
            if (layer.indexBuffer() != null && !layer.indexBuffer().isClosed()) {
                RenderSystem.getDevice().createCommandEncoder().writeToBuffer(layer.indexBuffer().slice(), resorted.indices());
            }
            MemoryUtil.memFree(resorted.indices());
            layer.sort().lastX = resorted.x();
            layer.sort().lastY = resorted.y();
            layer.sort().lastZ = resorted.z();
            layer.sort().pending = false;
        }
    }
}
