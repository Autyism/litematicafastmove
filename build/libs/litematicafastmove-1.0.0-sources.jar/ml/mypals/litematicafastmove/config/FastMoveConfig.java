package ml.mypals.litematicafastmove.config;

import com.google.common.collect.ImmutableMap;
import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.schematic.placement.SubRegionPlacement;
import fi.dy.masa.litematica.selection.Box;
import net.minecraft.core.BlockPos;

public class FastMoveConfig {
    public static boolean ENABLE_FAST_MOVE = true;
    // 所有投影都由独立网格渲染；关闭后只有体积 >= DETACHED_VOLUME_THRESHOLD 的投影被接管
    public static boolean TAKEOVER_ALL_PLACEMENTS = true;
    // 体积 (长*宽*高) 达到此值的投影，连续平移时推迟 WorldSchematic 的重写
    public static int DETACHED_VOLUME_THRESHOLD = 32768; // 例如 32x32x32 = 32768
    // 点击 Litematica 校验按钮后改为多线程校验
    public static boolean ENABLE_ASYNC_VERIFY = true;
    // 停止移动多久 (毫秒) 后，把推迟的 WorldSchematic 重写一次性提交
    public static long COMMIT_DELAY_MS = 1500;
    // 移动插值的时间常数 (毫秒)，越大越"拖"，0 关闭插值
    public static double MOVE_SMOOTHING_MS = 60;

    /**
     * 投影的方块 / 流体 / overlay 是否由独立网格渲染 (Litematica 的共享区块网格中跳过)
     */
    public static boolean isRenderTakenOver(SchematicPlacement placement) {
        if (!ENABLE_FAST_MOVE || placement == null) return false;
        long volume = getVolume(placement);
        return volume > 0 && (TAKEOVER_ALL_PLACEMENTS || volume >= DETACHED_VOLUME_THRESHOLD);
    }

    /**
     * 连续平移时是否推迟 WorldSchematic 的重写 (只对大型投影有意义，小投影直接走原版即可)
     */
    public static boolean shouldDeferCommit(SchematicPlacement placement) {
        if (!ENABLE_FAST_MOVE || placement == null) return false;
        return getVolume(placement) >= DETACHED_VOLUME_THRESHOLD;
    }

    private static long getVolume(SchematicPlacement placement) {
        long totalVolume = 0;
        ImmutableMap<String, Box> map = placement.getSubRegionBoxes(SubRegionPlacement.RequiredEnabled.PLACEMENT_ENABLED);
        for (Box b : map.values()) {
            BlockPos p1 = b.getPos1();
            BlockPos p2 = b.getPos2();
            if (p1 == null || p2 == null) continue;
            long dx = Math.abs(p1.getX() - p2.getX()) + 1L;
            long dy = Math.abs(p1.getY() - p2.getY()) + 1L;
            long dz = Math.abs(p1.getZ() - p2.getZ()) + 1L;
            totalVolume += dx * dy * dz;
        }
        return totalVolume;
    }
}
