package ml.mypals.litematicafastmove.mixin;

import ml.mypals.litematicafastmove.mesh.PlacementMeshManager;
import net.minecraft.client.multiplayer.ClientPacketListener;
import net.minecraft.network.protocol.game.ClientboundLevelChunkWithLightPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// 真实世界区块加载：这一整列都可能变化
@Mixin(value = ClientPacketListener.class, remap = false)
public abstract class MixinClientPacketListener {

    @Inject(method = "handleLevelChunkWithLight", at = @At("RETURN"))
    private void onChunkLoaded(ClientboundLevelChunkWithLightPacket packet, CallbackInfo ci) {
        PlacementMeshManager.markChunkDirty(packet.x(), packet.z());
    }
}
