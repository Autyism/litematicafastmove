package ml.mypals.litematicafastmove.mixin;

import ml.mypals.litematicafastmove.mesh.PlacementMeshManager;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

// 服务端方块更新 (单个方块与区段批量更新都会经过这里)：只重建受影响的区段
@Mixin(value = ClientLevel.class, remap = false)
public abstract class MixinClientLevel {

    @Inject(method = "setServerVerifiedBlockState", at = @At("HEAD"))
    private void onServerBlockUpdate(BlockPos pos, BlockState state, int flags, CallbackInfo ci) {
        PlacementMeshManager.markBlockDirty(pos);
    }
}
