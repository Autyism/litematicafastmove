package ml.mypals.litematicafastmove.sync;

import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import ml.mypals.litematicafastmove.config.FastMoveConfig;
import net.minecraft.core.BlockPos;
import net.minecraft.world.phys.Vec3;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 移动插值：大型投影的"显示原点"每帧以指数平滑追赶真实原点，
 * 独立网格、overlay、实体 / 方块实体都按显示原点绘制，移动时平滑滑过去而不是瞬移。
 *
 * 只影响渲染；投影的真实原点、WorldSchematic、校验等都立即使用新位置。
 * 线程：只在渲染线程访问。
 */
public final class MoveInterpolator {
    /** 一次跳跃超过这个距离 (格) 时直接瞬移，例如"移动到玩家位置" */
    private static final double SNAP_DISTANCE = 128.0;
    private static final double EPSILON = 1.0E-3;

    private static final Map<SchematicPlacement, double[]> DISPLAYED = new ConcurrentHashMap<>();
    private static long lastFrameNanos;

    /**
     * 每帧调用一次，推进所有投影的显示原点
     */
    public static void update() {
        long now = System.nanoTime();
        double dtMs = lastFrameNanos == 0 ? 0 : (now - lastFrameNanos) / 1.0E6;
        lastFrameNanos = now;

        double tau = FastMoveConfig.MOVE_SMOOTHING_MS;
        double alpha = tau <= 0 ? 1.0 : 1.0 - Math.exp(-Math.min(dtMs, 250.0) / tau);

        DISPLAYED.forEach((placement, displayed) -> {
            BlockPos target = placement.getOrigin();
            double dx = target.getX() - displayed[0];
            double dy = target.getY() - displayed[1];
            double dz = target.getZ() - displayed[2];

            if (alpha >= 1.0 || dx * dx + dy * dy + dz * dz > SNAP_DISTANCE * SNAP_DISTANCE) {
                displayed[0] = target.getX();
                displayed[1] = target.getY();
                displayed[2] = target.getZ();
                return;
            }

            displayed[0] = Math.abs(dx) < EPSILON ? target.getX() : displayed[0] + dx * alpha;
            displayed[1] = Math.abs(dy) < EPSILON ? target.getY() : displayed[1] + dy * alpha;
            displayed[2] = Math.abs(dz) < EPSILON ? target.getZ() : displayed[2] + dz * alpha;
        });
    }

    /**
     * 显示原点相对真实原点的滞后量 (显示 - 真实)；首次查询的投影没有滞后
     */
    public static Vec3 getLag(SchematicPlacement placement) {
        BlockPos origin = placement.getOrigin();
        double[] displayed = DISPLAYED.computeIfAbsent(placement, p -> new double[]{origin.getX(), origin.getY(), origin.getZ()});
        return new Vec3(displayed[0] - origin.getX(), displayed[1] - origin.getY(), displayed[2] - origin.getZ());
    }

    public static void forget(SchematicPlacement placement) {
        DISPLAYED.remove(placement);
    }

    public static void clear() {
        DISPLAYED.clear();
    }
}
