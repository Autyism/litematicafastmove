package ml.mypals.litematicafastmove.sync;

import fi.dy.masa.litematica.schematic.placement.SchematicPlacement;
import fi.dy.masa.litematica.schematic.placement.SubRegionPlacement;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * 大型投影被连续平移时，推迟 WorldSchematic 的重写。
 *
 * 方块几何由独立网格负责、移动即时生效；WorldSchematic 只服务于 overlay、校验器、
 * Easy Place 等功能，它的重写 (以及随之而来的 overlay 重建) 在停止移动一段时间后
 * 由 MixinSchematicPlacementManager 一次性提交。期间 base 区块被"冻结"，
 * 防止原版重建按新原点往旧区块写入错位数据。
 *
 * 方块与 overlay 在独立网格中随投影移动；提交前 WorldSchematic 里的实体、方块实体仍在旧位置，
 * 渲染时按坐标判断归属，平移 (当前原点 - base 原点)，不影响其他投影。
 *
 * 线程：状态只在客户端主线程修改；Placement Manager 守护线程只读取 {@link #frozenChunks} 快照。
 */
public final class PendingMoveTracker {
    public static final class MoveState {
        public final BlockPos baseOrigin;
        /** 移动开始前该投影占据的区块，即 WorldSchematic 中其数据实际所在的区块 */
        public final Set<ChunkPos> baseChunks;
        public volatile long lastMoveMs;

        MoveState(BlockPos baseOrigin, Set<ChunkPos> baseChunks) {
            this.baseOrigin = baseOrigin;
            this.baseChunks = baseChunks;
        }
    }

    private static final Map<SchematicPlacement, MoveState> STATES = new ConcurrentHashMap<>();
    /** 暂态期间被拦截的重建任务所在区块，解冻后需要补做 */
    private static final Set<Long> SKIPPED_REBUILDS = ConcurrentHashMap.newKeySet();
    private static volatile Set<Long> frozenChunks = Set.of();
    /** 移动中投影各子区域在 WorldSchematic 中的旧包围盒及其平移量，用于实体 / 方块实体 */
    private static volatile List<ShiftedBox> shiftedBoxes = List.of();

    private record ShiftedBox(int minX, int minY, int minZ, int maxX, int maxY, int maxZ,
                              SchematicPlacement placement, BlockPos baseOrigin) {
        boolean contains(int x, int y, int z) {
            return x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ;
        }
    }

    public static boolean hasAnyPending() {
        return !STATES.isEmpty();
    }

    public static MoveState get(SchematicPlacement placement) {
        return STATES.get(placement);
    }

    public static void onMoved(SchematicPlacement placement, BlockPos baseOrigin, Set<ChunkPos> baseChunks) {
        MoveState state = STATES.computeIfAbsent(placement, p -> new MoveState(baseOrigin, baseChunks));
        state.lastMoveMs = System.currentTimeMillis();
        rebuildFrozen();
    }

    public static MoveState remove(SchematicPlacement placement) {
        MoveState state = STATES.remove(placement);
        if (state != null) {
            rebuildFrozen();
        }
        return state;
    }

    public static List<SchematicPlacement> getPending() {
        return new ArrayList<>(STATES.keySet());
    }

    public static List<SchematicPlacement> getDueForCommit(long now, long settleMs) {
        List<SchematicPlacement> due = new ArrayList<>();
        STATES.forEach((placement, state) -> {
            if (now - state.lastMoveMs >= settleMs) due.add(placement);
        });
        return due;
    }

    public static void clear() {
        STATES.clear();
        SKIPPED_REBUILDS.clear();
        frozenChunks = Set.of();
        shiftedBoxes = List.of();
    }

    /**
     * 渲染线程：WorldSchematic 中位于 (x, y, z) 的实体 / 方块实体需要的平移量 (含移动插值)，不需要平移时返回 null
     */
    public static Vec3 getObjectShift(double x, double y, double z) {
        List<ShiftedBox> boxes = shiftedBoxes;
        if (boxes.isEmpty()) return null;

        int bx = (int) Math.floor(x), by = (int) Math.floor(y), bz = (int) Math.floor(z);
        for (ShiftedBox box : boxes) {
            if (box.contains(bx, by, bz)) {
                BlockPos delta = box.placement().getOrigin().subtract(box.baseOrigin());
                return MoveInterpolator.getLag(box.placement()).add(delta.getX(), delta.getY(), delta.getZ());
            }
        }
        return null;
    }

    /**
     * 守护线程：该区块的数据仍处于 base 坐标，不能按当前原点重新写入
     */
    public static boolean isFrozenChunk(int chunkX, int chunkZ) {
        Set<Long> frozen = frozenChunks;
        return !frozen.isEmpty() && frozen.contains(ChunkPos.pack(chunkX, chunkZ));
    }

    public static void markSkippedRebuild(int chunkX, int chunkZ) {
        SKIPPED_REBUILDS.add(ChunkPos.pack(chunkX, chunkZ));
    }

    /**
     * 取出已解冻的被拦截区块（调用前应已 {@link #remove} 对应投影）
     */
    public static List<ChunkPos> drainUnfrozenSkipped() {
        List<ChunkPos> result = new ArrayList<>();
        for (Long key : SKIPPED_REBUILDS) {
            ChunkPos pos = ChunkPos.unpack(key);
            if (!isFrozenChunk(pos.x(), pos.z()) && SKIPPED_REBUILDS.remove(key)) {
                result.add(pos);
            }
        }
        return result;
    }

    private static void rebuildFrozen() {
        Set<Long> frozen = new HashSet<>();
        List<ShiftedBox> boxes = new ArrayList<>();

        STATES.forEach((placement, state) -> {
            BlockPos delta = placement.getOrigin().subtract(state.baseOrigin);

            for (var box : placement.getSubRegionBoxes(SubRegionPlacement.RequiredEnabled.PLACEMENT_ENABLED).values()) {
                BlockPos min = box.getPos1().subtract(delta);
                BlockPos max = box.getPos2().subtract(delta);
                boxes.add(new ShiftedBox(Math.min(min.getX(), max.getX()), Math.min(min.getY(), max.getY()), Math.min(min.getZ(), max.getZ()),
                        Math.max(min.getX(), max.getX()), Math.max(min.getY(), max.getY()), Math.max(min.getZ(), max.getZ()),
                        placement, state.baseOrigin));
            }

            for (ChunkPos pos : state.baseChunks) {
                frozen.add(pos.pack());
            }
        });

        frozenChunks = Set.copyOf(frozen);
        shiftedBoxes = List.copyOf(boxes);
    }
}
